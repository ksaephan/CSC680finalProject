//
//  CollisionLogic.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/9/23.
//

import Foundation
import SwiftUI
import SpriteKit
import GameplayKit


//Categories of collision, credit to ChatGPT AI
//This table sets up collision variables for the collision logic
//these are bit values
struct PhysicsCategories{
    static let None : UInt32 = 0
    static let Player : UInt32 = 0b1 //1 in decimal
    static let Bullet : UInt32 = 0b10 //2 in decimal
    static let Enemy : UInt32 = 0b100 //4 in decimal
}


