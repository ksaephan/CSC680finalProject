//
//  enumGameState.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/9/23.
//

import Foundation
import SpriteKit


enum gameState{
    case preGame //welcome screen
    case inGame //playing screen
    case afterGame //win screen
}


