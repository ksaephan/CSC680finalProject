//
//  globalsVariables.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/9/23.
//

import Foundation
import SpriteKit

var gameScore = 0
let player = SKSpriteNode(imageNamed: "Player")
let bulletSound = SKAction.playSoundFileNamed("fireSound.mp3", waitForCompletion: false)
let explosionSound = SKAction.playSoundFileNamed("explodeSound.mp3", waitForCompletion: false)
let scoreLabel = SKLabelNode(fontNamed: "Arial")
let livesLabel = SKLabelNode(fontNamed: "Arial")
let currLevelLabel = SKLabelNode(fontNamed: "Arial")
let backgroundMusic = SKAudioNode.init(fileNamed: "retroBackgroundMusic.mp3")
let tapToStartLabel = SKLabelNode(fontNamed: "Arial")
var lastUpdateTime: TimeInterval = 0
var deltaFrameTime: TimeInterval = 0
var amountToMovePerSecond: CGFloat = 200.0 //controls how fast the background moves
