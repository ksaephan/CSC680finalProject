//
//  mainMenuScene.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/9/23.
//

import Foundation
import SpriteKit

//Main Menu
class MainMenuScene: SKScene {
    override func didMove(to view: SKView) {
        //Background Properties
        let background = SKSpriteNode(imageNamed: "backgroundGame")
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        background.size = self.size
        background.zPosition = 0
        self.addChild(background)
        
        //creator label
        let gameBy = SKLabelNode(fontNamed: "Arial")
        gameBy.text = "by Kao Saephan"
        gameBy.fontSize = 40
        gameBy.fontColor = SKColor.white
        gameBy.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.2)
        gameBy.zPosition = 1
        self.addChild(gameBy)
        
        //game name part 1
        let gameName1 = SKLabelNode(fontNamed: "Arial")
        gameName1.text = "Farm"
        gameName1.fontSize = 150
        gameName1.fontColor = SKColor.white
        gameName1.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.7)
        gameName1.zPosition = 1
        self.addChild(gameName1)
        
        //game name part 2
        let gameName2 = SKLabelNode(fontNamed: "Arial")
        gameName2.text = "Showdown"
        gameName2.fontSize = 150
        gameName2.fontColor = SKColor.white
        gameName2.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.625)
        gameName2.zPosition = 1
        self.addChild(gameName2)
        
        //start label
        let startGame = SKLabelNode(fontNamed: "Arial")
        startGame.text = "Start Game"
        startGame.fontSize = 100
        startGame.fontColor = SKColor.white
        startGame.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.4)
        startGame.zPosition = 1
        startGame.name = "startButton"
        self.addChild(startGame)
    }
    
    //making the start label into a button
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches {
            let pointOfTouch = touch.location(in: self)
            let nodeITapped = atPoint(pointOfTouch)
            
            //start button takes us into the game
            if nodeITapped.name == "startButton" {
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.5)
                self.view!.presentScene(sceneToMoveTo, transition: myTransition)
            }
        }
    }
    
    
    
} //end of MainMenuScene
