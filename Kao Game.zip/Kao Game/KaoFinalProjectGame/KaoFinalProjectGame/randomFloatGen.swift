//
//  randomFloatGen.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/9/23.
//

import Foundation

//Random float generators, credit to stackOverFlow website and ChatGPT
func random() -> CGFloat {
    return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
}
func random(min: CGFloat, max: CGFloat) -> CGFloat{
    return random() * (max - min) + min
}


