//
//  GameScene.swift
//  KaoFinalProjectGame
//
//  Created by Kao Saephan on 12/7/23.
//
import SwiftUI
import SpriteKit
import GameplayKit



class GameScene: SKScene, SKPhysicsContactDelegate {
    //global variables within the game
    var currentGameState = gameState.preGame
    var levelNumber = 0
    var livesNumber = 3
    var gameArea: CGRect
    
    //setup the playable game area, since game area will not fit the screen
    override init(size: CGSize) {
        let maxAspectRatio: CGFloat = 16.0/9.0
        let playableWidth = size.height / maxAspectRatio
        let margin = (size.width - playableWidth) / 2
        gameArea = CGRect(x: margin, y: 0, width: playableWidth, height: size.height)
        
        super.init(size: size)
        self.addChild(backgroundMusic)
    }
    
    //required code for the init
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //explosion properties
    func spawnExplosion(spawnPosition: CGPoint) {
        let explosion = SKSpriteNode(imageNamed: "explosion")
        explosion.position = spawnPosition
        explosion.zPosition = 3
        explosion.setScale(0)
        self.addChild(explosion)
        
        let scaleIn = SKAction.scale(to: 0.5, duration: 0.1)
        let fadeOut = SKAction.fadeOut(withDuration: 0.1)
        let delete = SKAction.removeFromParent()
        
        let explosionSequence = SKAction.sequence([explosionSound, scaleIn, fadeOut, delete])
        explosion.run(explosionSequence)
    }
    
    
    //setting up the game scene
    override func didMove(to view: SKView) {
        gameScore = 0
        
        //required to use physics for collisions
        self.physicsWorld.contactDelegate = self
        
        //moving the background, string together two instance of the background to create the illusion of a moving background credit to stackOverFlow for the logic
        for i in 0...1{
            //setting up the background of the main game
            let background = SKSpriteNode(imageNamed: "backgroundGame")
            background.name = "Background"
            background.size = self.size
            background.anchorPoint = CGPoint(x: 0.5, y: 0)
            background.position = CGPoint(x: self.size.width/2,
                                          y: self.size.height * CGFloat(i))
            background.zPosition = 0 //should be the furthest back, smallest
            self.addChild(background)
        }
            
        //Player data
        player.setScale(0.25) //sets the scale of the player sprite, decimal may work
        player.position = CGPoint(x: self.size.width/2, y: -self.size.height * 0.2)
        player.zPosition = 2 // leave 1 for bullets
        
        //player collision setup
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        player.physicsBody!.affectedByGravity = false
        player.physicsBody!.categoryBitMask = PhysicsCategories.Player
        player.physicsBody!.collisionBitMask = PhysicsCategories.None
        player.physicsBody!.contactTestBitMask = PhysicsCategories.Enemy
        self.addChild(player)
        
        //score properties
        scoreLabel.text = "Score: 0"
        scoreLabel.fontSize = 60
        scoreLabel.fontColor = SKColor.white
        scoreLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        scoreLabel.position = CGPoint(x: self.size.width * 0.20, y: self.size.height + scoreLabel.frame.size.height)
        scoreLabel.zPosition = 1000
        self.addChild(scoreLabel)
        
        //current level label properties
        currLevelLabel.text = "Level: \(levelNumber)"
        currLevelLabel.fontSize = 60
        currLevelLabel.fontColor = SKColor.white
        currLevelLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        currLevelLabel.position = CGPoint(x: self.size.width * 0.21 , y: self.size.height + currLevelLabel.frame.size.height)
        currLevelLabel.zPosition = 1000
        self.addChild(currLevelLabel)
        
        //lives properties
        livesLabel.text = "Life: 3"
        livesLabel.fontSize = 60
        livesLabel.fontColor = SKColor.white
        livesLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.right
        livesLabel.position = CGPoint(x: self.size.width * 0.80, y: self.size.height + livesLabel.frame.size.height)
        livesLabel.zPosition = 1000
        self.addChild(livesLabel)
        
        //fade in effect
        let moveOntoScreenAction1 = SKAction.moveTo(y: self.size.height * 0.85, duration: 0.3)
        let moveOnToScreenAction2 = SKAction.moveTo(y: self.size.height * 0.9, duration: 0.3)
        currLevelLabel.run(moveOntoScreenAction1)
        scoreLabel.run(moveOnToScreenAction2)
        livesLabel.run(moveOnToScreenAction2)
        
        //start labels
        tapToStartLabel.text = "Tap to Begin"
        tapToStartLabel.fontSize = 100
        tapToStartLabel.fontColor = SKColor.white
        tapToStartLabel.zPosition = 1
        tapToStartLabel.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        tapToStartLabel.alpha = 0
        self.addChild(tapToStartLabel)
        
        let fadeInAction = SKAction.fadeIn(withDuration: 0.3)
        tapToStartLabel.run(fadeInAction)
    }
    
    //calculate time per frame, amount to move per frame, credit to stackOverflow
    override func update(_ currentTime: TimeInterval) {
        //calculating time per frame
        if lastUpdateTime == 0 {
            lastUpdateTime = currentTime
        }
        else {
            deltaFrameTime = currentTime - lastUpdateTime
            lastUpdateTime = currentTime 
        }
        
        //moving background per frame
        let amountToMoveBackground = amountToMovePerSecond * CGFloat(deltaFrameTime)
        self.enumerateChildNodes(withName: "Background") {
            background, stop in
            
            //only scroll background when in game
            if self.currentGameState == gameState.inGame{
                background.position.y -= amountToMoveBackground
            }
            
            if background.position.y < -self.size.height {
                background.position.y += self.size.height * 2
            }
        }
    }
    
    //firing the bullet and bullet properties
    func fireBullet() {
        //bullet Properties
        let bullet = SKSpriteNode(imageNamed:"bullet")
        bullet.name = "Bullet"
        bullet.setScale(0.13)
        bullet.position = player.position
        bullet.zPosition = 1 // in front of backgroun but behind player
        
        //bullet collision setup
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
        bullet.physicsBody!.affectedByGravity = false
        bullet.physicsBody!.categoryBitMask = PhysicsCategories.Bullet
        bullet.physicsBody!.collisionBitMask = PhysicsCategories.None
        bullet.physicsBody!.contactTestBitMask = PhysicsCategories.Enemy
        self.addChild(bullet)
        
        //bullet movement
        let moveBullet = SKAction.moveTo(y:self.size.height + bullet.size.height, duration: 1)
        let deleteBullet = SKAction.removeFromParent()
        
        let bulletSequence = SKAction.sequence([bulletSound,moveBullet, deleteBullet])
        bullet.run(bulletSequence)
    }
    
    
    //collision logic and handling
    func didBegin(_ contact: SKPhysicsContact) {
        var body1 = SKPhysicsBody()
        var body2 = SKPhysicsBody()
        
        //Collision logic to remove the backwards collision scenarios,
        //example: in the case of 'bullet hits enemy', then 'enemy hits bullets' will never occur
        //this is making use of the physicsCategories table created above
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            body1 = contact.bodyA
            body2 = contact.bodyB
        }
        else {
            body1 = contact.bodyB
            body2 = contact.bodyA
        }
        
        //player has hit enemy
        if body1.categoryBitMask == PhysicsCategories.Player &&
            body2.categoryBitMask == PhysicsCategories.Enemy {
            
            //preventing two bullet colliding with 1 enemy
            if body1.node != nil{
                spawnExplosion(spawnPosition: body1.node!.position)
            }
            
            if body2.node != nil {
                spawnExplosion(spawnPosition: body2.node!.position)
            }
            
            body1.node?.removeFromParent() //delete player
            body2.node?.removeFromParent() //delete enemy
            
            runGameOver()
        }
        
        //bullet has hit enemy
        if body1.categoryBitMask == PhysicsCategories.Bullet &&
            body2.categoryBitMask == PhysicsCategories.Enemy &&
            (body2.node?.position.y)! < self.size.height {
            
            addScore() //bullet has hit enemy, so add 1 to score
            
            if body2.node != nil {
                spawnExplosion(spawnPosition: body2.node!.position)
            }
            
            body1.node?.removeFromParent() //delete bullet
            body2.node?.removeFromParent() //delete enemy
        }
    }
    
    //lose a life
    func loseALife(){
        livesNumber -= 1
        livesLabel.text = "Lives: \(livesNumber)"
        
        //text growth logic
        let scaleUp = SKAction.scale(to: 1.5, duration: 0.2)
        let scaleDown = SKAction.scale(to: 1, duration: 0.2)
        let scalesSequence = SKAction.sequence([scaleUp, scaleDown])
        livesLabel.run(scalesSequence)
        
        if livesNumber == 0 {
            runGameOver()
        }
    }
    
    //adds to the score
    func addScore(){
        gameScore += 1
        scoreLabel.text = "Score: \(gameScore)"
        
        //text growth logic
        let scaleUp = SKAction.scale(to: 1.5, duration: 0.2)
        let scaleDown = SKAction.scale(to: 1, duration: 0.2)
        let scalesSequence = SKAction.sequence([scaleUp, scaleDown])
        
        //after certain thresholds, difficulty level increases
        if gameScore == 3 || gameScore == 10 || gameScore == 20 {
            currLevelLabel.text = "Level: \(levelNumber)"
            currLevelLabel.run(scalesSequence)
            startNewLevel()
        }
    }
    
    
    //Level properties
    public func startNewLevel() {
        levelNumber += 1
        
        if self.action(forKey: "spawningEnemies") != nil {
            self.removeAction(forKey: "spawningEnemies")
        }
        
        var levelDuration = TimeInterval()
        
        switch levelNumber {
        case 1: levelDuration = 2
        case 2: levelDuration = 0.8
        case 3: levelDuration = 0.4
        case 4: levelDuration = 0.2
        default:
            levelDuration = 2
            print("Error in level design")
        }
        
        let spawn = SKAction.run(spawnEnemy)
        let waitToSpawn = SKAction.wait(forDuration: levelDuration)
        let spawnSequence = SKAction.sequence([waitToSpawn, spawn])
        let spawnForever = SKAction.repeatForever(spawnSequence)
        self.run(spawnForever, withKey: "spawningEnemies")
    }
    
    
    //enemies
    func spawnEnemy() {
        //spawn location setup
        let randomXStart = random(min: CGRectGetMinX(gameArea) + player.size.width * 1.1, max: CGRectGetMaxX(gameArea) - player.size.width * 1.1)
        let randomXEnd = random(min: CGRectGetMinX(gameArea) + player.size.width * 1.1, max: CGRectGetMaxX(gameArea) - player.size.width * 1.1)
        
        let startPoint = CGPoint(x: randomXStart, y: self.size.height * 1.2)
        let endPoint = CGPoint(x: randomXEnd, y: -self.size.height * 0.2)
        
        //enemy ship properties
        let enemy = SKSpriteNode(imageNamed: "enemy")
        enemy.name = "Enemy"
        enemy.setScale(0.2)
        enemy.position = startPoint
        enemy.zPosition = 2
        
        //enemy collision setup
        enemy.physicsBody = SKPhysicsBody(rectangleOf: enemy.size)
        enemy.physicsBody!.affectedByGravity = false
        enemy.physicsBody!.categoryBitMask = PhysicsCategories.Enemy
        enemy.physicsBody!.collisionBitMask = PhysicsCategories.None
        enemy.physicsBody!.contactTestBitMask = PhysicsCategories.Player | PhysicsCategories.Bullet
        self.addChild(enemy)
        
        //enemy movement
        let moveEnemy = SKAction.move(to: endPoint, duration: 3.5)
        let deleteEnemy = SKAction.removeFromParent()
        let loseALifeAction = SKAction.run(loseALife)
        let enemySequence = SKAction.sequence([moveEnemy, deleteEnemy, loseALifeAction])
        
        if currentGameState == gameState.inGame{
            enemy.run(enemySequence)
        }
        
        let dx = endPoint.x - startPoint.x
        let dy = endPoint.y - startPoint.y
        let amountToRotate = atan2(dy, dx)
        enemy.zRotation = amountToRotate
    }
    
    //controlling gamestate
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if currentGameState == gameState.preGame {
            startGame()
        }
        
        if currentGameState == gameState.inGame {
            fireBullet()
        }
    }
    
    //moving player sprite
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches{
            let pointOfTouch = touch.location(in: self)
            let previousPointOfTouch = touch.previousLocation(in: self)
            
            let amountDragged = pointOfTouch.x - previousPointOfTouch.x
            
            if currentGameState == gameState.inGame{
                player.position.x += amountDragged
            }
            
            //limiting player movements to the playable screen
            if player.position.x > CGRectGetMaxX(gameArea) - player.size.width * 1.1{
                player.position.x = CGRectGetMaxX(gameArea) - player.size.width * 1.1
            }
            
            if player.position.x < CGRectGetMinX(gameArea) + player.size.width * 1.1{
                player.position.x = CGRectGetMinX(gameArea) + player.size.width * 1.1
            }
        }
    }
    
    //starting the game
    func startGame() {
        currentGameState = gameState.inGame
        
        let fadeOutAction = SKAction.fadeOut(withDuration: 0.5)
        let deleteAction = SKAction.removeFromParent()
        let deleteSequence = SKAction.sequence([fadeOutAction, deleteAction])
        tapToStartLabel.run(deleteSequence)
        
        let moveShipOnScreen = SKAction.moveTo(y: self.size.height * 0.2, duration: 0.5)
        let startLevelAction = SKAction.run(startNewLevel)
        let startGameSequence = SKAction.sequence([moveShipOnScreen, startLevelAction])
        player.run(startGameSequence)
    }
    
    //ending the game
    public func runGameOver() {
        currentGameState = gameState.afterGame
        self.removeAllActions()
        
        //stopping all bullets
        self.enumerateChildNodes(withName: "Bullet"){
            bullet, stop in
            bullet.removeAllActions()
        }
        
        //stopping all enemies
        self.enumerateChildNodes(withName: "Enemy"){
            enemy, stop in
            enemy.removeAllActions()
        }
        
        let changeSceneAction = SKAction.run(changeScene)
        let waitToChangeScene = SKAction.wait(forDuration: 1)
        let changeSceneSequence = SKAction.sequence([waitToChangeScene, changeSceneAction])
        self.run(changeSceneSequence)
    }
    
    //move to win gme over scene
    func changeScene(){
        let sceneToMoveTo = GameOverScene(size:self.size)
        sceneToMoveTo.scaleMode = self.scaleMode
        let myTransition = SKTransition.fade(withDuration: 0.5)
        self.view!.presentScene(sceneToMoveTo, transition: myTransition)
    }
    
}
